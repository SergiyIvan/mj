package ukr.lpu.cs.mj;

import com.oracle.truffle.api.dsl.TypeSystem;

@TypeSystem({int.class, double.class, char.class, String.class, boolean.class})
public abstract class MJTypes {
}
