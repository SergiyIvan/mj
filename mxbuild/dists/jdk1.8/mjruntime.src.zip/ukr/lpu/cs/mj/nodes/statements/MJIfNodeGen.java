// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.MJStatementNode;
import ukr.lpu.cs.mj.nodes.statements.MJIfNode;

@GeneratedBy(MJIfNode.class)
public final class MJIfNodeGen extends MJIfNode {

    @Child private MJExpressionNode conditionNode_;
    @CompilationFinal private int state_;

    private MJIfNodeGen(MJStatementNode thenPartNode, MJStatementNode elsePartNode, MJExpressionNode conditionNode) {
        super(thenPartNode, elsePartNode);
        this.conditionNode_ = conditionNode;
    }

    private MJIfNodeGen(MJStatementNode thenPartNode, MJExpressionNode conditionNode) {
        super(thenPartNode);
        this.conditionNode_ = conditionNode;
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        boolean conditionNodeValue_;
        try {
            conditionNodeValue_ = this.conditionNode_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(frameValue, ex.getResult());
            return;
        }
        if (state != 0 /* is-active doVoid(VirtualFrame, boolean) */) {
            doVoid(frameValue, conditionNodeValue_);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(frameValue, conditionNodeValue_);
        return;
    }

    private void executeAndSpecialize(VirtualFrame frameValue, Object conditionNodeValue) {
        int state = state_;
        if (conditionNodeValue instanceof Boolean) {
            boolean conditionNodeValue_ = (boolean) conditionNodeValue;
            this.state_ = state = state | 0b1 /* add-active doVoid(VirtualFrame, boolean) */;
            doVoid(frameValue, conditionNodeValue_);
            return;
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.conditionNode_}, conditionNodeValue);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else {
            return NodeCost.MONOMORPHIC;
        }
    }

    public static MJIfNode create(MJStatementNode thenPartNode, MJStatementNode elsePartNode, MJExpressionNode conditionNode) {
        return new MJIfNodeGen(thenPartNode, elsePartNode, conditionNode);
    }

    public static MJIfNode create(MJStatementNode thenPartNode, MJExpressionNode conditionNode) {
        return new MJIfNodeGen(thenPartNode, conditionNode);
    }

}
