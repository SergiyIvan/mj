// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.statements.MJBreakStatement;

@GeneratedBy(MJBreakStatement.class)
public final class MJBreakStatementNodeGen extends MJBreakStatement {

    private MJBreakStatementNodeGen() {
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        doBreak();
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJBreakStatement create() {
        return new MJBreakStatementNodeGen();
    }

}
