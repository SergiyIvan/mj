// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.NodeCost;
import ukr.lpu.cs.mj.nodes.statements.MJContinueStatement;

@GeneratedBy(MJContinueStatement.class)
public final class MJContinueStatementNodeGen extends MJContinueStatement {

    private MJContinueStatementNodeGen() {
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        doContinue();
        return;
    }

    @Override
    public NodeCost getCost() {
        return NodeCost.MONOMORPHIC;
    }

    public static MJContinueStatement create() {
        return new MJContinueStatementNodeGen();
    }

}
