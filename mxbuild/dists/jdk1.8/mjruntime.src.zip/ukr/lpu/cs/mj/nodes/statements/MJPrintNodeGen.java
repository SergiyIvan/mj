// CheckStyle: start generated
package ukr.lpu.cs.mj.nodes.statements;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import ukr.lpu.cs.mj.nodes.MJExpressionNode;
import ukr.lpu.cs.mj.nodes.statements.MJPrintNode;

@GeneratedBy(MJPrintNode.class)
public final class MJPrintNodeGen extends MJPrintNode {

    @Child private MJExpressionNode child0_;
    @CompilationFinal private int state_;

    private MJPrintNodeGen(MJExpressionNode child0) {
        this.child0_ = child0;
    }

    @Override
    public void executeVoid(VirtualFrame frameValue) {
        int state = state_;
        if ((state & 0b11101) == 0 /* only-active print(int) */ && state != 0  /* is-not print(String) && print(int) && print(double) && print(char) && print(boolean) */) {
            executeVoid_int0(frameValue, state);
            return;
        } else if ((state & 0b11011) == 0 /* only-active print(double) */ && state != 0  /* is-not print(String) && print(int) && print(double) && print(char) && print(boolean) */) {
            executeVoid_double1(frameValue, state);
            return;
        } else if ((state & 0b10111) == 0 /* only-active print(char) */ && state != 0  /* is-not print(String) && print(int) && print(double) && print(char) && print(boolean) */) {
            executeVoid_char2(frameValue, state);
            return;
        } else if ((state & 0b1111) == 0 /* only-active print(boolean) */ && state != 0  /* is-not print(String) && print(int) && print(double) && print(char) && print(boolean) */) {
            executeVoid_boolean3(frameValue, state);
            return;
        } else {
            executeVoid_generic4(frameValue, state);
            return;
        }
    }

    private void executeVoid_int0(VirtualFrame frameValue, int state) {
        int child0Value_;
        try {
            child0Value_ = this.child0_.executeInt(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(ex.getResult());
            return;
        }
        assert (state & 0b10) != 0 /* is-active print(int) */;
        print(child0Value_);
        return;
    }

    private void executeVoid_double1(VirtualFrame frameValue, int state) {
        double child0Value_;
        try {
            child0Value_ = this.child0_.executeDouble(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(ex.getResult());
            return;
        }
        assert (state & 0b100) != 0 /* is-active print(double) */;
        print(child0Value_);
        return;
    }

    private void executeVoid_char2(VirtualFrame frameValue, int state) {
        char child0Value_;
        try {
            child0Value_ = this.child0_.executeCharacter(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(ex.getResult());
            return;
        }
        assert (state & 0b1000) != 0 /* is-active print(char) */;
        print(child0Value_);
        return;
    }

    private void executeVoid_boolean3(VirtualFrame frameValue, int state) {
        boolean child0Value_;
        try {
            child0Value_ = this.child0_.executeBoolean(frameValue);
        } catch (UnexpectedResultException ex) {
            executeAndSpecialize(ex.getResult());
            return;
        }
        assert (state & 0b10000) != 0 /* is-active print(boolean) */;
        print(child0Value_);
        return;
    }

    private void executeVoid_generic4(VirtualFrame frameValue, int state) {
        Object child0Value_ = this.child0_.execute(frameValue);
        if ((state & 0b1) != 0 /* is-active print(String) */ && child0Value_ instanceof String) {
            String child0Value__ = (String) child0Value_;
            print(child0Value__);
            return;
        }
        if ((state & 0b10) != 0 /* is-active print(int) */ && child0Value_ instanceof Integer) {
            int child0Value__ = (int) child0Value_;
            print(child0Value__);
            return;
        }
        if ((state & 0b100) != 0 /* is-active print(double) */ && child0Value_ instanceof Double) {
            double child0Value__ = (double) child0Value_;
            print(child0Value__);
            return;
        }
        if ((state & 0b1000) != 0 /* is-active print(char) */ && child0Value_ instanceof Character) {
            char child0Value__ = (char) child0Value_;
            print(child0Value__);
            return;
        }
        if ((state & 0b10000) != 0 /* is-active print(boolean) */ && child0Value_ instanceof Boolean) {
            boolean child0Value__ = (boolean) child0Value_;
            print(child0Value__);
            return;
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        executeAndSpecialize(child0Value_);
        return;
    }

    private void executeAndSpecialize(Object child0Value) {
        int state = state_;
        if (child0Value instanceof String) {
            String child0Value_ = (String) child0Value;
            this.state_ = state = state | 0b1 /* add-active print(String) */;
            print(child0Value_);
            return;
        }
        if (child0Value instanceof Integer) {
            int child0Value_ = (int) child0Value;
            this.state_ = state = state | 0b10 /* add-active print(int) */;
            print(child0Value_);
            return;
        }
        if (child0Value instanceof Double) {
            double child0Value_ = (double) child0Value;
            this.state_ = state = state | 0b100 /* add-active print(double) */;
            print(child0Value_);
            return;
        }
        if (child0Value instanceof Character) {
            char child0Value_ = (char) child0Value;
            this.state_ = state = state | 0b1000 /* add-active print(char) */;
            print(child0Value_);
            return;
        }
        if (child0Value instanceof Boolean) {
            boolean child0Value_ = (boolean) child0Value;
            this.state_ = state = state | 0b10000 /* add-active print(boolean) */;
            print(child0Value_);
            return;
        }
        throw new UnsupportedSpecializationException(this, new Node[] {this.child0_}, child0Value);
    }

    @Override
    public NodeCost getCost() {
        int state = state_;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if ((state & (state - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static MJPrintNode create(MJExpressionNode child0) {
        return new MJPrintNodeGen(child0);
    }

}
