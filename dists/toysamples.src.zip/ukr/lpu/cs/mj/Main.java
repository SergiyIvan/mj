package ukr.lpu.cs.mj;

public class Main {

}
